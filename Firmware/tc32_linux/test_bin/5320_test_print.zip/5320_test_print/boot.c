#include "bsp.h"
#include "uprintf.h"




void lwr_irq_hdlr() {

}




static inline  void delay(unsigned int ms)
{
	volatile unsigned int i,j;
	volatile unsigned char bc;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<20;j++)
		{
			bc++;
		}
	}
	
}
static void delay2(unsigned int ms)
{
	volatile unsigned int i,j;
	volatile unsigned char bc;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<20;j++)
		{
			bc++;
		}
	}
	
}
static inline void delay3(unsigned int ms)
{
	volatile unsigned int i,j;
	volatile unsigned char bc;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<20;j++)
		{
			bc++;
		}
	}
	
}
#define TEST_0 0
#define TEST_1 1
#define TEST_2 0


unsigned long  bug_cc;
unsigned char  array_test[4][16];

void sys_init( )
{
	bug_cc=0;
}

void fun2(int *a )
{
	*a=4;
}

void main()
{
	
	int aaa= -1;
    sys_init();
    fun2(&bug_cc);
	while(1) {
		if(bug_cc>10)  fun2(&bug_cc);;
		bug_cc++;
		aaa++;


		write_reg8(0x8005ae, 0x10);
		write_reg8(0x8005ae,0x00);

	}
		
}
