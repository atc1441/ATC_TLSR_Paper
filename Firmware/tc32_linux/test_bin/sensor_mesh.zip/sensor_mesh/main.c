#include "drivers.h"

unsigned long  firmwareVersion;



void sys_init(void)
{
	struct  S_SYS_CTL  sys_ctl;
	sys_ctl.rst0.all = 0x00;
	sys_ctl.rst1.all = 0x00;
	sys_ctl.rst2.all = 0x00;
	sys_ctl.clk0.all = 0xff;
	sys_ctl.clk1.all = 0xff;
	sys_ctl.clk2.all = 0xff;
	Sys_Init(&sys_ctl,SYS_CLK_HS_DIV,6);
	Rf_Init(RF_OSC_12M,RF_MODE_ZIGBEE_250K);
	WaitUs(10000);
}


unsigned char  beacon_packet[128] __attribute__ ((aligned (4))) = {0x07,0x00,0x00,0x00,0x08,0x00,0x00,0x00,0x12,0x34,0x56,0x78,0x12,0x34,0x56,0x78,0x12,0x34,0x56,0x78};
int debug_cnt;
void main(void)
{
	sys_init();
	debug_cnt = 0;
	Rf_TrxStateSet(RF_MODE_TX,10);//Ƶ��2410
	while(1)
	{
		WaitUs(10000);//wait pllclock
		Rf_TxPkt(beacon_packet);
		while(RF_TxFinish()==0);
		//RF_TxFinishClearFlag();
		debug_cnt++;
		Rf_TxFinishClearFlag();

	}

}
