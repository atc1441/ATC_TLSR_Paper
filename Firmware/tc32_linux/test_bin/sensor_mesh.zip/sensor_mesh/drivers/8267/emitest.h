/*
 * emitest.h
 *
 *  Created on: 2016-6-30
 *      Author: Administrator
 */

#ifndef EMITEST_H_
#define EMITEST_H_
extern int pnGen(int state);
extern int Rf_EmiInit(void);
extern void	Rf_EmiCarrierOnlyTest(enum M_RF_POWER power_level,signed char rf_chn);
extern void	Rf_EmiCarrierDataTest(enum M_RF_POWER power_level,signed char rf_chn);
extern void Rf_EmiDataUpdate(void);
extern void Rf_EmiRxTest(unsigned char *addr,signed char rf_chn,signed char buffer_size,unsigned char  pingpong_en);
extern unsigned char Rf_EmiTxInit(enum M_RF_POWER power_level,signed char rf_chn);
extern unsigned char Rf_EmiSingleTx(unsigned char *addr);

#endif /* EMITEST_H_ */
