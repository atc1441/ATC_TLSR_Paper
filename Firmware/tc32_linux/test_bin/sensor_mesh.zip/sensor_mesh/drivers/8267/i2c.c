#include "bsp.h"
#include "i2c.h"
#include "gpio.h"

static unsigned char select_pin_num(GPIO_Pin gpio_x){
	unsigned char pinx_num = gpio_x&0xff;
	switch(pinx_num){
		case 0x01:
			return 0;
		break;
		case 0x02:
			return 1;
		break;
		case 0x04:
			return 2;
		break;
		case 0x08:
			return 3;
		break;
		case 0x10:
			return 4;
		break;
		case 0x20:
			return 5;
		break;
		case 0x40:
			return 6;
		break;
		case 0x80:
			return 7;
		break;
		default:
		break;
	}
}

//////now gpio_x1 and gpio_x2 only suport c0 and c1
void i2c_pin_initial(GPIO_Pin gpio_sda,GPIO_Pin gpio_scl){
	
	GPIO_SetGPIOEnable(gpio_sda,Bit_RESET);///A3  as no gpio 
	GPIO_SetGPIOEnable(gpio_scl,Bit_RESET);///A4  as no gpio
	
	unsigned char GPIO_num = (unsigned char)(gpio_sda>>8);
	switch(GPIO_num){
		case 0x00://////GROUPA_GP3 and GROUPA_GP4
		write_reg8(0x8005b0,read_reg8(0x8005b0)|0x18);///enable the i2c function of A3 and A4.   0x5b0[3]and 0x5b0[4],datasheet is error
		write_reg8(0x8005b1,read_reg8(0x8005b1)&0x3f);////disable the i2c function of B6 and B7
		write_reg8(0x8005b2,read_reg8(0x8005b2)&0xfc);////disable the i2c function of C0 and C1
		break;
		case 0x01:///////GROUPB_GP6 and GROUPB_GP7
		write_reg8(0x8005b1,read_reg8(0x8005b1)|0xC0);////enable the i2c function of B6 and B7
		write_reg8(0x8005b0,read_reg8(0x8005b0)&0xe7);///disable the i2c function of A3 and A4.   0x5b0[3]and 0x5b0[4],datasheet is error
		write_reg8(0x8005b2,read_reg8(0x8005b2)&0xfc);////disable the i2c function of C0 and C1
		break;
		case 0x02:////GROUPC_GP0 and GROUPC_GP1
		write_reg8(0x8005b2,read_reg8(0x8005b2)|0x03);////enable the i2c function of C0 and C1
		write_reg8(0x8005b0,read_reg8(0x8005b0)&0xe7);///disable the i2c function of A3 and A4.   0x5b0[3]and 0x5b0[4],datasheet is error
		write_reg8(0x8005b1,read_reg8(0x8005b1)&0x3f);////disable the i2c function of B6 and B7
		break;
		default:
		break;
	}
	/////enable internal 10k pull-up resistors of SDA and SCL pin
	unsigned char sda_anreg_offset = ((gpio_sda - GPIO_GROUPA)>>8)<<3;
	unsigned char scl_anreg_offset = ((gpio_scl - GPIO_GROUPA)>>8)<<3;
	unsigned char sda_pin_no = select_pin_num(gpio_sda);
	unsigned char scl_pin_no = select_pin_num(gpio_scl);
	
	unsigned char sda_pullup_reg;
	unsigned char sda_pullup_bit;
	sda_pullup_reg = ((sda_anreg_offset+sda_pin_no)*2+4)/8 + 0x0a;
	sda_pullup_bit = ((sda_anreg_offset+sda_pin_no)*2+4)%8;
	
	unsigned char scl_pullup_reg;
	unsigned char scl_pullup_bit;
	scl_pullup_reg = ((scl_anreg_offset+scl_pin_no)*2+4)/8 + 0x0a;
	scl_pullup_bit = ((scl_anreg_offset+scl_pin_no)*2+4)%8;

	WriteAnalogReg(sda_pullup_reg,ReadAnalogReg(sda_pullup_reg)&(~ BIT(sda_pullup_bit)));
	WriteAnalogReg(sda_pullup_reg,ReadAnalogReg(sda_pullup_reg)|BIT(sda_pullup_bit+1));

	WriteAnalogReg(scl_pullup_reg, ReadAnalogReg(scl_pullup_reg)&(~ BIT(scl_pullup_bit)));
    WriteAnalogReg(scl_pullup_reg, ReadAnalogReg(scl_pullup_reg)|BIT(scl_pullup_bit+1));
}

void i2c_master_init(unsigned char slave_id,unsigned char div_clock){
	//write_reg8(0x800000,0x20);////system_clock/2*0x10
	write_reg8(0x800000,div_clock);/////Fi2c = system_clock/2*div_clock
	
	write_reg8(0x800001,slave_id);//////slave address
	write_reg8(0x800003,read_reg8(0x800003)|0x02);/////enable master mode
	
}

void I2C_SlaveInit(I2C_SlaveMode mode,unsigned char * pBuf,unsigned char id_addr, I2C_IrqStatus irq){
	unsigned char tmp;
	////set slave_id
	write_reg8(0x800001,id_addr);
	
	/******2. Set I2C Slave Mode(DMA or Mapping)******/
    if (mode == I2C_SLAVE_MAP) {////default is DMA mode
    	//set 0x03[2] to enable mapping mode
	    tmp = read_reg8(0x800003);
	    tmp |= 0x04;
	    write_reg8(0x800003, tmp);
	    //set buf's address low byte
	    tmp = (unsigned int)pBuf & 0xff; 
	    write_reg8(0x80003e, tmp);
	    //set buf's address high byte
	    tmp = ((unsigned int)pBuf>>8) & 0xff; 
	    write_reg8(0x80003f, tmp);
    }
	
	/******3. Set I2C Slave Irq******/
    if (irq == I2C_IRQ_ENABLE) {
        write_reg8(0x800640, read_reg8(0x800640)|0x80); //enable irq_host_cmd
    	write_reg8(0x800643, read_reg8(0x800643)|0x01); //enable irq function
    }
    else {
    	write_reg8(0x800640, read_reg8(0x800640)&0x7f); //disable irq_host_cmd
    }
}




void i2c_write_buff_dma(unsigned short s_addr,unsigned char * pbuf,unsigned int num){
	unsigned char addr_H,addr_L;
	unsigned int i=0;
	addr_H = (s_addr>>8)&0xff;
	addr_L = s_addr&0xff;
	write_reg8(0x800004,addr_H);
	write_reg8(0x800005,addr_L);
	write_reg8(0x800001,read_reg8(0x800001)&0xfe);//slave_id | 0x01,.i.e read data. R:High  W:Low
	write_reg8(0x800007,0x17);////lanuch start /id/04/05    start
	while(read_reg8(0x800002)&0x01);
	for(i=0;i<num;i++){
		write_reg8(0x800006,pbuf[i]);
		write_reg8(0x800007,0x08);///launch data read cycle
		while(read_reg8(0x800002)&0x01);
	}
	write_reg8(0x800007,0x20);////launch stop cycle
	while(read_reg8(0x800002)&0x02);
}


void i2c_read_buff_dma(unsigned short s_addr,unsigned char * pbuf,unsigned int num){
	unsigned char addr_H,addr_L;
	unsigned int i = 0;
	addr_H = (s_addr>>8)&0xff;
	addr_L = s_addr&0xff;
	/****write address that maybe readed in,frame include:start + id + addr_H + addr_L + stop***/
	write_reg8(0x800001,read_reg8(0x800001)&0xfe);
	write_reg8(0x800004,addr_H);
	write_reg8(0x800005,addr_L);
	write_reg8(0x800007,0x37);///start/stop/ID/04/05
	while(read_reg8(0x800002)&0x01);

	/***read data from the address add_H+add_L***/
	write_reg8(0x800001,read_reg8(0x800001)|0x01);//slave_id | 0x01,.i.e read data. R:High  W:Low
	write_reg8(0x800007,0x11);///start/id
	while(read_reg8(0x800002)&0x01);
	if(num>1){
		for(i=0;i<num;i++){
			write_reg8(0x800007,0x48);////launch  data read cycle/enable read id...if data is not the last byte readed from slave,master should not ACK to slave,so write 0x48
			while(read_reg8(0x800002)&0x01);
			pbuf[i] = read_reg8(0x800006);
			if(num==i+2){
				write_reg8(0x800007,0xc8);/////if the data is the last byte readed from slave,the master should ACK to slave,so write 0xc8.
				while(read_reg8(0x800002)&0x01);
				pbuf[i+1] = read_reg8(0x800006);
				break;
			}
		}
	}else{
		write_reg8(0x800007,0xc8);
		while(read_reg8(0x800002)&0x01);
		pbuf[0] = read_reg8(0x800006);
	}
	write_reg8(0x800007,0x20);////launch stop cycle
	while(read_reg8(0x800002)&0x02);
}
void i2c_write_buff_mapping(unsigned char * pbuf,unsigned int num){
	unsigned int i=0;
	write_reg8(0x800001,read_reg8(0x800001)&0xfe);//slave_id | 0x01,.i.e read data. R:High  W:Low
	write_reg8(0x800007,0x11);////lanuch start /id
	while(read_reg8(0x800002)&0x01);
	for(i=0;i<num;i++){
		write_reg8(0x800006,pbuf[i]);
		write_reg8(0x800007,0x08);///launch data read cycle
		while(read_reg8(0x800002)&0x01);
	}
	write_reg8(0x800007,0x20);////launch stop cycle
	while(read_reg8(0x800002)&0x02);
}

void i2c_read_buff_mapping(unsigned char * pbuf,unsigned int num){
	unsigned int i=0;
	write_reg8(0x800001,read_reg8(0x800001)|0x01);//slave_id | 0x01,.i.e read data. R:High  W:Low
	write_reg8(0x800007,0x10);////start
	while(read_reg8(0x800002)&0x01);
	write_reg8(0x800007,0x01);////id
	while(read_reg8(0x800002)&0x01);
	write_reg8(0x800007,0xc8);
	if(num>1){
		for(i=0;i<num;i++){
			write_reg8(0x800007,0x48);////enable ACK in read command/launch  data read cycle  C8  48
			//WaitUs(105);//////105:0a(1)  85:error
			while(read_reg8(0x800002)&0x01);
			pbuf[i] = read_reg8(0x800006);
			if(num==i+2){
				write_reg8(0x800007,0xc8);
				while(read_reg8(0x800002)&0x01);
				pbuf[i+1] = read_reg8(0x800006);
				break;
			}
		}
	}
	else
	{
		write_reg8(0x800007,0xc8);
		while(read_reg8(0x800002)&0x01);
		pbuf[0] = read_reg8(0x800006);
	}
	write_reg8(0x800007,0x20);////launch stop cycle
	while(read_reg8(0x800002)&0x02);
}

I2C_IrqSrc I2C_SlaveIrqGet(void){
	unsigned char hostStatus = read_reg8(0x800021);
	if(hostStatus&0x04){
		return I2C_IRQ_HOST_READ_ONLY;
	}
	else if(hostStatus&0x02){
		return I2C_IRQ_HOST_READ_WRITE;////the bit actually indicate read and write,but because the "return read_only"is before "read_write",so if return"read_write" indicate write only
	}
	else{
		return I2C_IRQ_NONE;
	}
}


void I2C_SlaveIrqClr(I2C_IrqSrc src){
	if(src==I2C_IRQ_HOST_READ_ONLY){
		write_reg8(0x800022,read_reg8(0x800022)|0x04);
	}
	else if(src==I2C_IRQ_HOST_READ_WRITE){
		write_reg8(0x800022,read_reg8(0x800022)|0x02);
	}
	else{

	}
}

