#ifndef I2C_H
#define I2C_H
#include "gpio.h"

typedef enum {
	I2C_IRQ_NONE = 0,
	I2C_IRQ_HOST_READ_WRITE,
	I2C_IRQ_HOST_READ_ONLY,
}I2C_IrqSrc;

typedef enum {
	I2C_SLAVE_DMA = 0,
	I2C_SLAVE_MAP,
}I2C_SlaveMode;

typedef enum {
	I2C_IRQ_DISABLE = 0,
	I2C_IRQ_ENABLE,
}I2C_IrqStatus;

extern void i2c_pin_initial(GPIO_Pin gpio_sda, GPIO_Pin gpio_scl);
extern void i2c_master_init(unsigned char slave_id,unsigned char div_clock);
void I2C_SlaveInit(I2C_SlaveMode mode,unsigned char * pBuf,unsigned char id_addr, I2C_IrqStatus irq);
void i2c_write_buff_dma(unsigned short s_addr,unsigned char * pbuf,unsigned int num);
void i2c_read_buff_dma(unsigned short s_addr,unsigned char * pbuf,unsigned int num);
void i2c_write_buff_mapping(unsigned char * pbuf,unsigned int num);
void i2c_read_buff_mapping(unsigned char * pbuf,unsigned int num);
I2C_IrqSrc I2C_SlaveIrqGet(void);
void I2C_SlaveIrqClr(I2C_IrqSrc src);


#endif 