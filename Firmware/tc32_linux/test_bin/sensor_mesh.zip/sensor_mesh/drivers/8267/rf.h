/**
* @file      	rf.h
*
* @brief       	8267_bleplus
*
* @date     	2015-06-25
*/
#ifndef		RF_H
#define     RF_H

enum  M_OSC_SEL {
  RF_OSC_16M = 0,  
  RF_OSC_12M = 1
};
enum  M_RF_TR_MODE {
	STX = 0,
	STR = 1,
	SRT = 2,
};
enum  M_RF_MODE {     // now only 2M mode is supported
	 RF_MODE_BLE_2M = 0,
	 RF_MODE_BLE_1M = 1,
	 RF_MODE_ZIGBEE_250K = 2,
	 RF_MODE_PRIVATE_2M = 3,
	 RF_MODE_STANDARD_BLE_1M =4
};
enum  M_RF_STATE {
  RF_MODE_TX = 0,
  RF_MODE_RX = 1,
  RF_MODE_AUTO=2,
  RF_MODE_OFF = 3

};
enum M_RF_POWER{
	RF_POWER_7dBm	= 0,
	RF_POWER_5dBm	= 1,
	RF_POWER_m0P6dBm	= 2,
	RF_POWER_m4P3dBm	= 3,
	RF_POWER_m9P5dBm	= 4,
	RF_POWER_m13P6dBm	= 5,
	RF_POWER_m18P8dBm	= 6,
	RF_POWER_m23P3dBm	= 7,
	RF_POWER_m27P5dBm	= 8,
	RF_POWER_m30dBm	= 9,
	RF_POWER_m37dBm	= 10,
	RF_POWER_OFF	= 11,
};



extern	int	 Rf_Init( enum  M_OSC_SEL  osc_sel,enum M_RF_MODE m);
extern	 void Rf_ModeSet(enum M_RF_MODE m);
extern void Rf_BaseBandReset (void);
extern   unsigned char  Rf_TrxStateSet(enum M_RF_STATE  state ,signed char channel);
extern  void Rf_TxPkt (unsigned char* addr);
extern	void Rf_PowerLevelSet(enum M_RF_POWER level);
extern void  Rf_RxBufferSet(unsigned char *  addr, int size, unsigned char  pingpong_en);
extern unsigned char Rf_RxBufferRequest(void);
extern void  Rf_RxBufferClearFlag(unsigned char  idx);
extern unsigned char  RF_TxFinish(void);
extern void Rf_TxFinishClearFlag (void);


extern void Rf_StartStx  (unsigned char* tx_addr,unsigned int tick);
extern void Rf_StartStxToRx  ( unsigned char* tx_addr ,unsigned int tick,unsigned short timeout_us);
extern void Rf_StartSrxToTx  (unsigned char* tx_addr  ,unsigned int tick,unsigned int timeout_us);

extern void Rf_TxAccessCodeSelect (unsigned char  idx);
extern void Rf_AccessCodeSetting01 (unsigned char  idx,unsigned long long  access_code);
extern void Rf_AccessCodeSetting2345 (unsigned char  idx,unsigned char  prefix);
extern void Rf_RxAccessCodeEnable (unsigned char enable);
extern void Rf_AccessCodeLengthSetting (unsigned char length);

extern void Rf_SetGainManualMax (void);
extern void Rf_SetAGC (void);
extern void Rf_UpdateTpValue(enum M_RF_MODE mode ,unsigned  char tp0,unsigned  char tp1);
#endif
