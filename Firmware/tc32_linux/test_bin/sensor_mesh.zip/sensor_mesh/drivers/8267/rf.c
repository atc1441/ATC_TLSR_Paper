/**********************************************************************************************************************
* Filename�� 	rf.c
* Description��	This file contains the RF driver functions for the Telink 8267.
* Version�� 		V1.1
* Author��		kaixin.chen@telink-semi.com
* Created Date�� 2015/06/25
*
* Notes��		V1.1(2016/7/20 kaixin)
*					add RF_MODE_STANDARD_BLE_1M rf mode (this mode can communicate with the application)
*					add function Rf_SetGainManualMax and Rf_SetAGC
*					add function Rf_UpdateTpValue to update Tp
*					EMI related functions are separated out as an independent C source file
*					fix zigbee mode make rx packet have length information
*				V1.2(2016/7/28 kaixin)
*					fix zigbee preamble 0xf4->0xf5
**********************************************************************************************************************/
#include "bsp.h"
#include "rf.h"


#define		SS		0x800f24



const unsigned char tbl_agc[] = {
	0x31,0x32,0x33,0x30,0x38,0x3c,0x2c,0x18 ,0x1c,0x0c,0x0c,0x00,0x00,0x00,0x00,0x00,
	0x0a,0x0f,0x15,0x1b,0x21,0x27,0x2e,0x32 ,0x38,0x3e
};

const TBLCMDSET  tbl_rf_ini[] = {

	0x06, 0x00,  TCMD_UNDER_BOTH | TCMD_WAREG, //power down control.
	0x8f, 0x38,  TCMD_UNDER_BOTH | TCMD_WAREG, //boot rx vco current, temporary fix
	0xa2, 0x2c,  TCMD_UNDER_BOTH | TCMD_WAREG, //pa_ramp_target ****0-5bit

	0xa0, 0x28,  TCMD_UNDER_BOTH | TCMD_WAREG, //dac datapath delay ******change  remington 0x26

	0x04, 0x7c,  TCMD_UNDER_BOTH | TCMD_WAREG,
	0xa7, 0x61,  TCMD_UNDER_BOTH | TCMD_WAREG,
	0x8d, 0x67,  TCMD_UNDER_BOTH | TCMD_WAREG,
	0xac, 0xa7,  TCMD_UNDER_BOTH | TCMD_WAREG,/////analog reg 0xac,change 0xaa to 0xa7,based on sihui 

	0x04ca, 0x88,	TCMD_UNDER_BOTH | TCMD_WRITE,	// ********enable DC distance bit 3
	0x04cb, 0x04,	TCMD_UNDER_BOTH | TCMD_WRITE,	// ********eset distance
	0x042d, 0x33,	TCMD_UNDER_BOTH | TCMD_WRITE,	// ********DC alpha=1/8, bit[6:4]
	
	//AGC_table
	0x430,0x12, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x43d,0xb1, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x438,0xb7, TCMD_UNDER_BOTH | TCMD_WRITE,


};

//RxMaxGain
const TBLCMDSET  tbl_rf_ini_manual_agc[] = {               // 16M crystal
	0x0433, 0x00,	TCMD_UNDER_BOTH | TCMD_WRITE,	// set mgain disable 01 -> 00
	0x0434, 0x01,	TCMD_UNDER_BOTH | TCMD_WRITE,	// pel0: 21 -> 01
	0x043a, 0x77,	TCMD_UNDER_BOTH | TCMD_WRITE,	// Rx signal power change threshold: 22 -> 77
	0x043e, 0xc9,	TCMD_UNDER_BOTH | TCMD_WRITE,	// set rx peak detect manual: 20 -> c9
	0x04cd, 0x06,	TCMD_UNDER_BOTH | TCMD_WRITE,	// fix rst_pga=0: len = 0 enable
};


const TBLCMDSET  tbl_rf_ini_16M[] = {               // 16M crystal
	//0x04eb, 0x60,	TCMD_UNDER_BOTH | TCMD_WRITE,   // auto
	//0x99, 	0x31,  TCMD_UNDER_BOTH | TCMD_WAREG,	// gauss filter sel: 16M
	//0x82,	0x14,  TCMD_UNDER_BOTH | TCMD_WAREG,	// gauss filter sel: 16M
	
};

const TBLCMDSET  tbl_rf_ini_12M[] = {               // 12M crystal
	//////0x04eb, 0xe0,  TCMD_UNDER_BOTH | TCMD_WRITE,	// RX freq regisgter: 4d4
	//////0x99, 	0xb1,  TCMD_UNDER_BOTH | TCMD_WAREG,	// gauss filter sel: 16M
	////////0x82,	0x00,  TCMD_UNDER_BOTH | TCMD_WAREG,	//enable rxadc clock
	//0x9e, 	0x82,  TCMD_UNDER_BOTH | TCMD_WAREG, 	//reg_dc_mod (500K)
};

// rf mode
////////////////////////////////////////////////////////////////////////////////////////////////

const TBLCMDSET  tbl_rf_zigbee_250k[] = {
	  0x9e, 0xad,  TCMD_UNDER_BOTH | TCMD_WAREG,   //reg_dc_mod (500K); ble: 250k
	  0xa3, 0x10,  TCMD_UNDER_BOTH | TCMD_WAREG,   //pa_ramp_en = 1, pa ramp table max
	  0xaa, 0x2a,  TCMD_UNDER_BOTH | TCMD_WAREG,  //filter iq_swap, 2M bandwidth
	  0x93, 0x50,  TCMD_UNDER_BOTH | TCMD_WAREG,

	  0x0400, 0x03, TCMD_UNDER_BOTH | TCMD_WRITE, // 250K mode
	  0x0401, 0x40, TCMD_UNDER_BOTH | TCMD_WRITE, // pn enable
	  0x0402, 0x26, TCMD_UNDER_BOTH | TCMD_WRITE, // 8-byte pre-amble
	  0x0404, 0xc0, TCMD_UNDER_BOTH | TCMD_WRITE, // head_mode/crc_mode: normal c0
	  0x0405, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // access code length 4
	  0x0408, 0xc9, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte3
	  0x0409, 0x8a, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte2
	  0x040a, 0x11, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte1
	  0x040b, 0xf8, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte0

	  0x0420, 0x90, TCMD_UNDER_BOTH | TCMD_WRITE, // sync threshold: 1e (4); 26 (5)
	  0x0421, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE, // no avg
	  0x0422, 0x1a, TCMD_UNDER_BOTH | TCMD_WRITE, // threshold
	  0x0424, 0x52, TCMD_UNDER_BOTH | TCMD_WRITE, // number for sync: bit[6:4]
	  0x0428, 0xe0, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x042b, 0xf5, TCMD_UNDER_BOTH | TCMD_WRITE, // access code: 1
	  0x042c, 0x88, TCMD_UNDER_BOTH | TCMD_WRITE, // maxiumum length 48-byte
	  0x043b, 0x8c, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x0464, 0x06, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x04cd, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x0f03, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE, // bit3: crc2_en; normal 1e

	  //AGC_table
	  0x043a, 0x33, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x04c0, 0x81, TCMD_UNDER_BOTH | TCMD_WRITE,
	  
	  0x04eb, 0xa0, TCMD_UNDER_BOTH | TCMD_WRITE,//[6]lowswap for rx integer/frac auto calculation(for zigbee +4M problem)


};

const TBLCMDSET  tbl_rf_ble_2m[] = {

	0x9e, 0xad,  TCMD_UNDER_BOTH | TCMD_WAREG, 	//*****reg_dc_mod (500KHz*128/126)****remington  	reg_dc_mod (500K)	0x82
	0xa3, 0xd0,  TCMD_UNDER_BOTH | TCMD_WAREG,//********[7:6] disable gauflt [5] LUT 2M or 1M
	0x93, 0x50,  TCMD_UNDER_BOTH | TCMD_WAREG,//*****dac gain settting
	0xaa, 0x2e,  TCMD_UNDER_BOTH | TCMD_WAREG,//*******filter iq_swap, adjust the bandwidth*****remington 0x2e

	0x0400, 0x0f, TCMD_UNDER_BOTH | TCMD_WRITE, // new 2M mode
	0x0401, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0402, 0x2b, TCMD_UNDER_BOTH | TCMD_WRITE, // 8-byte pre-amble
	0x0404, 0xc5, TCMD_UNDER_BOTH | TCMD_WRITE, // head_mode/crc_mode: normal c5

	0x0405, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // access code length 4
	0x0408, 0xf8, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte3
	0x0409, 0x11, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte2
	0x040a, 0x8a, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte1
	0x040b, 0xc9, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte0

	0x0420, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE, // sync threshold: 1e (4); 26 (5)
	0x0421, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // no avg
	0x0422, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE, // threshold
	0x0424, 0x12, TCMD_UNDER_BOTH | TCMD_WRITE, // number fo sync: bit[6:4]
	0x0428, 0x80, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x042b, 0xf1, TCMD_UNDER_BOTH | TCMD_WRITE, // access code: 1
	0x042c, 0x80, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x043b, 0x8c, TCMD_UNDER_BOTH | TCMD_WRITE, //enable timer stamp & dc output ( need move to Rx Setting)
	0x0464, 0x07, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04cd, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // enable packet lenght = 0
	0x0f03, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE,

	0x043a, 0x22, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04c0, 0x87, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04eb, 0xe0, TCMD_UNDER_BOTH | TCMD_WRITE,//[6]zigbee
};


// ble 1m mode
const TBLCMDSET  tbl_rf_ble_1m[] = {

	0x9e, 0x56,  TCMD_UNDER_BOTH | TCMD_WAREG, 	//*****reg_dc_mod (500KHz*128/126)****remington  	reg_dc_mod (500K)	0x82
	0xa3, 0xf0,  TCMD_UNDER_BOTH | TCMD_WAREG,//********[7:6] disable gauflt [5] LUT 2M or 1M
	0x93, 0x28,  TCMD_UNDER_BOTH | TCMD_WAREG,//*****dac gain settting
	0xaa, 0x26,  TCMD_UNDER_BOTH | TCMD_WAREG,//*******filter iq_swap, adjust the bandwidth*****remington 0x2e

	0x0400, 0x0f, TCMD_UNDER_BOTH | TCMD_WRITE, // new 2M mode
	0x0401, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0402, 0x2b, TCMD_UNDER_BOTH | TCMD_WRITE, // 8-byte pre-amble
	0x0404, 0xd5, TCMD_UNDER_BOTH | TCMD_WRITE, // head_mode/crc_mode: normal c5
	0x0405, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0408, 0xc9, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0409, 0x8a, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x040a, 0x11, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x040b, 0xf8, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0420, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE, // sync threshold: 1e (4); 26 (5)
	0x0421, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // no avg
	0x0422, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE, // threshold
	0x0424, 0x12, TCMD_UNDER_BOTH | TCMD_WRITE, // number fo sync: bit[6:4]
	0x0428, 0x80, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x042b, 0xf1, TCMD_UNDER_BOTH | TCMD_WRITE, // access code: 1
	0x042c, 0x80, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x043b, 0x8c, TCMD_UNDER_BOTH | TCMD_WRITE, //enable timer stamp & dc output ( need move to Rx Setting)
	0x0464, 0x07, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04cd, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // enable packet lenght = 0
	0x0f03, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE,

	0x043a, 0x22, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04c0, 0x87, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04eb, 0xe0, TCMD_UNDER_BOTH | TCMD_WRITE,//[6]
};

const TBLCMDSET  tbl_rf_standard_ble_1m[] = {

	0x9e, 0x56,  TCMD_UNDER_BOTH | TCMD_WAREG, 	//*****reg_dc_mod (500KHz*128/126)****remington  	reg_dc_mod (500K)	0x82
	0xa3, 0xf0,  TCMD_UNDER_BOTH | TCMD_WAREG,//********[7:6] disable gauflt [5] LUT 2M or 1M
	0x93, 0x28,  TCMD_UNDER_BOTH | TCMD_WAREG,//*****dac gain settting
	0xaa, 0x26,  TCMD_UNDER_BOTH | TCMD_WAREG,//*******filter iq_swap, adjust the bandwidth*****remington 0x2e

	0x0400, 0x0f, TCMD_UNDER_BOTH | TCMD_WRITE, // new 2M mode
	0x0401, 0x08, TCMD_UNDER_BOTH | TCMD_WRITE, // 1M/2M PN enable
	0x0402, 0x24, TCMD_UNDER_BOTH | TCMD_WRITE, // 8-byte pre-amble
	0x0404, 0xf5, TCMD_UNDER_BOTH | TCMD_WRITE, // ble_wt
	0x0405, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0408, 0xc9, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0409, 0x8a, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x040a, 0x11, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x040b, 0xf8, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x0420, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE, // sync threshold: 1e (4); 26 (5)
	0x0421, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // no avg
	0x0422, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE, // threshold
	0x0424, 0x12, TCMD_UNDER_BOTH | TCMD_WRITE, // number fo sync: bit[6:4]
	0x0428, 0x80, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x042b, 0xf1, TCMD_UNDER_BOTH | TCMD_WRITE, // access code: 1
	0x042c, 0x80, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x043b, 0x8c, TCMD_UNDER_BOTH | TCMD_WRITE, //enable timer stamp & dc output ( need move to Rx Setting)
	0x0464, 0x07, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04cd, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // enable packet lenght = 0
	0x0f03, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE,

	0x043a, 0x22, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04c0, 0x87, TCMD_UNDER_BOTH | TCMD_WRITE,
	0x04eb, 0xe0, TCMD_UNDER_BOTH | TCMD_WRITE,//[6]
};

const TBLCMDSET  tbl_rf_private_2M[] = {
	  0x9e, 0xad,  TCMD_UNDER_BOTH | TCMD_WAREG,   //reg_dc_mod (500K); ble: 250k
	  0xa3, 0x10,  TCMD_UNDER_BOTH | TCMD_WAREG,   //pa_ramp_en = 1, pa ramp table max
	  0xaa, 0x2e,  TCMD_UNDER_BOTH | TCMD_WAREG,  //filter iq_swap, 2M bandwidth
	  0x93, 0x50,  TCMD_UNDER_BOTH | TCMD_WAREG,

	  0x0400, 0x0b, TCMD_UNDER_BOTH | TCMD_WRITE, // 250K mode
	  0x0401, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE, // pn enable
	  0x0402, 0x26, TCMD_UNDER_BOTH | TCMD_WRITE, // 8-byte pre-amble
	  0x0404, 0xc0, TCMD_UNDER_BOTH | TCMD_WRITE, // head_mode/crc_mode: normal c0
	  0x0405, 0x04, TCMD_UNDER_BOTH | TCMD_WRITE, // access code length 4
	  0x0408, 0xc9, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte3
	  0x0409, 0x8a, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte2
	  0x040a, 0x11, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte1
	  0x040b, 0xf8, TCMD_UNDER_BOTH | TCMD_WRITE, // access code byte0

	  0x0420, 0x90, TCMD_UNDER_BOTH | TCMD_WRITE, // sync threshold: 1e (4); 26 (5)
	  0x0421, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE, // no avg
	  0x0422, 0x1a, TCMD_UNDER_BOTH | TCMD_WRITE, // threshold
	  0x0424, 0x52, TCMD_UNDER_BOTH | TCMD_WRITE, // number for sync: bit[6:4]
	  0x0428, 0xe4, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x042b, 0xe3, TCMD_UNDER_BOTH | TCMD_WRITE, // access code: 1
	  0x042c, 0x88, TCMD_UNDER_BOTH | TCMD_WRITE, // maxiumum length 48-byte
	  0x043b, 0x8c, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x0464, 0x06, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x04cd, 0x00, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x0f03, 0x1e, TCMD_UNDER_BOTH | TCMD_WRITE, // bit3: crc2_en; normal 1e

	  //AGC_table
	  0x043a, 0x22, TCMD_UNDER_BOTH | TCMD_WRITE,
	  0x04c0, 0x87, TCMD_UNDER_BOTH | TCMD_WRITE,

	  0x04eb, 0xe0, TCMD_UNDER_BOTH | TCMD_WRITE,//[6]lowswap for rx integer/frac auto calculation(for zigbee +4M problem)


};

const char tbl_rf_power[] = {
  //a2    04    a7    8d
	0x25, 0x7c, 0x67, 0x67,		// 7 dBm
	0x0a, 0x7c, 0x67, 0x67,		// 5 dBm
	0x06, 0x74, 0x43, 0x61,		// -0.6
	0x06, 0x64, 0xc2, 0x61,		// -4.3
	0x06, 0x64, 0xc1, 0x61,		// -9.5
	0x05, 0x7c, 0x67, 0x67,		// -13.6
	0x03, 0x7c, 0x67, 0x67,		// -18.8
	0x02, 0x7c, 0x67, 0x67,		// -23.3
	0x01, 0x7c, 0x67, 0x67,		// -27.5
	0x00, 0x7c, 0x67, 0x67,		// -30
	0x00, 0x64, 0x43, 0x61,		// -37
	0x00, 0x64, 0xcb, 0x61,		// -max	power down PA & PAD
};
#define		gain_base		TP_GAIN0[g_rf_mode]
#define		gain_g			((TP_GAIN0[g_rf_mode] - TP_GAIN1[g_rf_mode])*256/80)
unsigned  char  TP_GAIN0[5] = {0x43,0x20,0x43,0x43,0x20};
unsigned  char  TP_GAIN1[5] = {0x3e,0x1c,0x3e,0x3e,0x1c};
enum   M_RF_MODE   g_rf_mode;
unsigned char rx_fifo_num=0;
unsigned char tx_fifo_num=0;
unsigned char  *  g_rf_stx_buffer_ptr;
unsigned char  *  g_rf_srx_buffer_ptr;
unsigned char  * g_rf_rx_buffer_ptr;
int				 g_rf_rx_buffer_size;
unsigned char    g_rf_rx_pingpong_en;
unsigned short g_rf_tx_single_fifo_length;
unsigned short g_rf_rx_single_fifo_length;



int	 Rf_Init( enum  M_OSC_SEL  osc_sel,enum M_RF_MODE m)
{
	unsigned  char   i;
	LoadTblCmdSet (tbl_rf_ini, sizeof (tbl_rf_ini)/sizeof (TBLCMDSET));
	if(osc_sel == RF_OSC_12M)
	{
		LoadTblCmdSet (tbl_rf_ini_12M, sizeof (tbl_rf_ini_12M)/sizeof (TBLCMDSET));
	}
	else
	{
		LoadTblCmdSet (tbl_rf_ini_16M, sizeof (tbl_rf_ini_16M)/sizeof (TBLCMDSET));
	}
	for (i=0; i<26; i++)
		write_reg8 (0x800480+i, tbl_agc[i]);	//set AGC table

	//LoadTblCmdSet (tbl_rf_ini_manual_agc, sizeof (tbl_rf_ini_manual_agc)/sizeof (TBLCMDSET));

	if(m == RF_MODE_BLE_2M)
	{
		LoadTblCmdSet (tbl_rf_ble_2m, sizeof (tbl_rf_ble_2m)/sizeof (TBLCMDSET));
	}
	else if(m == RF_MODE_BLE_1M)
	{
		LoadTblCmdSet (tbl_rf_ble_1m, sizeof (tbl_rf_ble_1m)/sizeof (TBLCMDSET));
	}
	else if(m == RF_MODE_ZIGBEE_250K)
	{
	   LoadTblCmdSet (tbl_rf_zigbee_250k, sizeof (tbl_rf_zigbee_250k)/sizeof (TBLCMDSET));

	}
	else if(m == RF_MODE_PRIVATE_2M)
	{
	   LoadTblCmdSet (tbl_rf_private_2M, sizeof (tbl_rf_private_2M)/sizeof (TBLCMDSET));

	}
	else if(m == RF_MODE_STANDARD_BLE_1M)
	{
		LoadTblCmdSet (tbl_rf_standard_ble_1m, sizeof (tbl_rf_standard_ble_1m)/sizeof (TBLCMDSET));
	}

	else
	{
		return  -1;
	}

	g_rf_mode = m;
	return  0;
}
void Rf_SetGainManualMax (void)
{
	write_reg8 (0x800433, 0x00);//  set mgain disable
	write_reg8 (0x800434, 0x01);//  [6:4]pel0
	write_reg8 (0x80043a, 0x77);//	Rx signal power change threshold
	write_reg8 (0x80043e, 0xc9);//  set rx peak detect manual
	if((RF_MODE_BLE_1M ==g_rf_mode)||(RF_MODE_BLE_2M ==g_rf_mode)||(RF_MODE_STANDARD_BLE_1M ==g_rf_mode))
	{
		write_reg8 (0x8004cd, 0x06);//  [1:0]fix rst_pga=0 [2]len_0_en(ble)
	}
	else
	{
		write_reg8 (0x8004cd, 0x02);//  [1:0]fix rst_pga=0
	}

}
void Rf_SetAGC (void)
{
	write_reg8 (0x800433, 0x01);
	write_reg8 (0x800434, 0x21);
	if( RF_MODE_ZIGBEE_250K == g_rf_mode)
	{
		write_reg8 (0x80043a, 0x33);
	}
	else
	{
		write_reg8 (0x80043a, 0x22);
	}

	write_reg8 (0x80043e, 0x20);
	if((RF_MODE_BLE_1M == g_rf_mode)||(RF_MODE_BLE_2M == g_rf_mode)||(RF_MODE_STANDARD_BLE_1M == g_rf_mode))
	{
		write_reg8 (0x8004cd, 0x04);//  [1:0]fix rst_pga=0 [2]len_0_en(ble)
	}
	else
	{
		write_reg8 (0x8004cd, 0x00);//  [1:0]fix rst_pga=0
	}
}

void Rf_ModeSet(enum M_RF_MODE m)
{
	if(m == RF_MODE_BLE_2M)
	{
		LoadTblCmdSet (tbl_rf_ble_2m, sizeof (tbl_rf_ble_2m)/sizeof (TBLCMDSET));
	}
	else if(m == RF_MODE_BLE_1M)
	{

		LoadTblCmdSet (tbl_rf_ble_1m, sizeof (tbl_rf_ble_1m)/sizeof (TBLCMDSET));
	}
	else if(m == RF_MODE_ZIGBEE_250K)
	{
	   LoadTblCmdSet (tbl_rf_zigbee_250k, sizeof (tbl_rf_zigbee_250k)/sizeof (TBLCMDSET));
	}
	else if(m == RF_MODE_PRIVATE_2M)
	{
	   LoadTblCmdSet (tbl_rf_private_2M, sizeof (tbl_rf_private_2M)/sizeof (TBLCMDSET));

	}
	else if(m == RF_MODE_STANDARD_BLE_1M)
	{
		LoadTblCmdSet (tbl_rf_standard_ble_1m, sizeof (tbl_rf_standard_ble_1m)/sizeof (TBLCMDSET));
	}

	g_rf_mode = m;
}



void Rf_BaseBandReset (void)
{
	write_reg8(0x800060,0x80);
	write_reg8(0x800060,0x00);
}


unsigned char  Rf_TrxStateSet(enum M_RF_STATE  state ,signed char channel)
{
    unsigned char  err = 0;
	unsigned  long  fre;
	/////////////////// turn on LDO and baseband PLL ////////////////
	//WriteAnalogReg (0x06, 0x00);
	//write_reg8 (0x800f16, 0x29);
	if(state == RF_MODE_TX)
	{
		write_reg8  (0x800f02, 0x45);
		fre = 2400 + channel;
		write_reg16 (0x8004d6, fre);
		write_reg8  (0x800f02, 0x55);
		//write_reg8  (0x80050f, 0x80);
	}
	else if(state == RF_MODE_RX)
	{
		write_reg8  (0x800f02, 0x45);
		fre = 2400 + channel;
		write_reg16 (0x8004d6, fre);
		write_reg8  (0x800f02, 0x65);
		write_reg8 (0x800428, read_reg8(0x800428)| BIT(0));	// rx enable
	}
	else if(state == RF_MODE_AUTO)
	{
		fre = 2400 + channel;
		write_reg16 (0x8004d6, fre);
		//write_reg16(0x800f1c, 0x03); //tx_irq and rx_irq
		//write_reg8(0x800641, 0x20);
		//write_reg8(0x800643, 0x01);
	}
	else if(state == RF_MODE_OFF)
    {
	    WriteAnalogReg (0x06,0xff); 		//  power down analog module 
		WriteAnalogReg (0x05,0xe2); 		//  power down analog module
	}
	else
	{
	    err = 1;
	}
	WriteAnalogReg(0x93, gain_base - (channel * gain_g >> 8));   	// set tp_gain
	 //2482--41 2484--42 ....2500--50
	//2400--61 2398--60 ....2380--51
	if(g_rf_mode == RF_MODE_STANDARD_BLE_1M)
	{
		channel = channel >> 1;
		if (channel < 1)
			channel = 61+channel;
		else if (channel < 2)
			channel = 37;
		else if (channel < 13)
			channel -= 2;
		else if (channel == 13)
			channel = 38;
		else if (channel < 40)
			channel -= 3;
		else if(channel == 40)
			channel = 39;
		else if(channel < 51)
			channel = channel;
		write_reg8 (0x80040d, channel);

	}
	return  err;

}

void Rf_TxPkt (unsigned char* addr)
{
		write_reg16 (0x80050c, (unsigned short)(addr));
		//write_reg8(0x80050e,0x10);
		//write_reg8  (0x80050f, 0x80);
		write_reg8 (0x800524, 0x08);
}

void Rf_StartStx  (unsigned char* tx_addr,unsigned int tick)
{
	 write_reg8(0x800f16, read_reg8(0x800f16) | 0x04);	// Enable cmd_schedule mode
	write_reg32(0x800f18, tick);						// Setting schedule trigger time
	write_reg16 (0x80050c, (unsigned short)(tx_addr));
	write_reg8 (0x800f00, 0x85);						// single TX

	//write_reg8(0x80050e,0x10);
	//write_reg8  (0x80050f, 0x80);
}


void Rf_StartStxToRx  ( unsigned char* tx_addr ,unsigned int tick,unsigned short timeout_us)
{
	//write_reg8 (0x800f03, 0x1f);
	//write_reg32 (0x800f2c, 0x0fffffff);
	write_reg16(0x800f0a, timeout_us-1);
	write_reg32(0x800f18, tick);						// Setting schedule trigger time
    write_reg8(0x800f16, read_reg8(0x800f16) | 0x04);	// Enable cmd_schedule mode
    write_reg16 (0x80050c, (unsigned short)(tx_addr));
	write_reg8  (0x800f00, 0x87);						// single tx2rx
}

void Rf_StartSrxToTx  (unsigned char* tx_addr  ,unsigned int tick,unsigned int timeout_us)
{
	write_reg32 (0x800f28, timeout_us-1);					// first timeout
	write_reg32(0x800f18, tick);						// Setting schedule trigger time
    write_reg8(0x800f16, read_reg8(0x800f16) | 0x04);	// Enable cmd_schedule mode
    write_reg16 (0x80050c, (unsigned short)(tx_addr));
	write_reg16 (0x800f00, 0x88);						// single rx2tx
}


void  Rf_RxBufferSet(unsigned char *  addr, int size, unsigned char  pingpong_en)
{
    unsigned char mode;
	mode = pingpong_en ? 0x03 : 0x01;
    write_reg16 (0x800508, (unsigned short)(addr));
    write_reg8(0x80050a, size>>4);
	write_reg8(0x80050b,mode);
	g_rf_rx_buffer_ptr = (unsigned char *) addr;
	g_rf_rx_buffer_size = size;
	g_rf_rx_pingpong_en = pingpong_en;
}

unsigned char Rf_RxBufferRequest(void)
{
    int i;
	int loop;
	unsigned char * ptr;
	loop = g_rf_rx_pingpong_en ? 2 : 1;
	ptr = NULL;
	for(i=0;i<loop;i++)
	{
		if (read_reg8(0x800526+i) & 0x04)  // is not empty
		{
			 break;
		}
	}
	return i;   // 0  &  1  

}

void  Rf_RxBufferClearFlag(unsigned char  idx)
{
	write_reg8(0x800526+idx, 0x04);
}

unsigned char  RF_TxFinish(void)
{
	return  (read_reg8(0x800f20) & 0x02);
	//return  read_reg8(0x800524);
}

void Rf_TxFinishClearFlag (void)
{
	write_reg8 (0x800f20, read_reg8(0x800f20)|0x02);
}

void Rf_TxAccessCodeSelect (unsigned char  idx)
{
	write_reg8 (0x800f15, read_reg8(0x800f15) & 0xf8 | idx);//Tx_Channel_man[2:0]
}
void Rf_AccessCodeLengthSetting (unsigned char length)
{
	write_reg8 (0x800405,read_reg8(0x800405)&0xf8|length);//access_byte_num[2:0]
	if( 5 == length )
		{

			write_reg8 (0x800420,0x28);//access_bit_threshold
		}
		else if( 4 == length )
		{

			write_reg8 (0x800420,0x20);//access_bit_threshold
		}
		else if( 3 == length )
		{

			write_reg8 (0x800420,0x18);//access_bit_threshold
		}
}

void Rf_AccessCodeSetting01 (unsigned char  idx,unsigned long long  access_code)
{
	unsigned char length=0;
	length = read_reg8 (0x800405);
	if( 5 == length )
	{
		if(0 == idx)
		{
			write_reg32 (0x800408,(unsigned int)access_code);//access_code 0
			write_reg8 (0x80040c,(unsigned char)(access_code>>32));
		}
		else if(1 == idx)
		{
			write_reg32 (0x800410,(unsigned int)access_code);//access_code 1
			write_reg8 (0x800414,(unsigned char)(access_code>>32));
		}
	}
	else if( 4 == length )
	{
		if(0 == idx)
		{
			write_reg32 (0x800408,(unsigned int)access_code);//access_code 0
		}
		else if(1 == idx)
		{
			write_reg32 (0x800410,(unsigned int)access_code);//access_code 1
		}
	}
	else if( 3 == length )
	{
		if(0 == idx)
		{
			write_reg16 (0x800408,(unsigned short)access_code);//access_code 0
			write_reg8 (0x80040a,(unsigned char)(access_code>>16));//access_code 0
		}
		else if(1 == idx)
		{
			write_reg16 (0x800410,(unsigned short)access_code);//access_code 1
			write_reg8 (0x800412,(unsigned char)(access_code>>16));
		}

	}
}

void Rf_AccessCodeSetting2345 (unsigned char  idx,unsigned char  prefix)
{
	write_reg8 (0x800418+idx-2,prefix);//access_code 2~5
}

void Rf_RxAccessCodeEnable (unsigned char enable)
{
	write_reg8 (0x800407,read_reg8(0x800407) & 0xc0 | enable);//rx_access_code_chn_en
}

void Rf_PowerLevelSet(enum M_RF_POWER level)
{
	unsigned char *p;
	if (level + 1 > (sizeof (tbl_rf_power)>>2)) {
		level = (sizeof (tbl_rf_power)>>2) - 1;
	}
	p = tbl_rf_power + level * 4;
	WriteAnalogReg (0xa2, *p ++);
	WriteAnalogReg (0x04, *p ++);
	WriteAnalogReg (0xa7, *p ++);
	WriteAnalogReg (0x8d, *p ++);
}

unsigned int Rf_FsmIsIdle(void)
{
    return (read_reg8(SS)==0);
}


// just for debug

// set max receive length  // need check
//0x042c
void  Rf_SetMaxRcvLen(unsigned char len)
{
   write_reg8(0x80042c,len);
}
/**********************************************************************************************************************
**********************************************************************************************************************/
void Rf_UpdateTpValue(enum M_RF_MODE mode ,unsigned  char tp0,unsigned  char tp1)
{
	if((mode == RF_MODE_BLE_1M)||(mode == RF_MODE_STANDARD_BLE_1M))
	{
		TP_GAIN0[1]=tp0;
		TP_GAIN1[1]=tp1;
		TP_GAIN0[4]=tp0;
		TP_GAIN1[4]=tp1;
	}
	else
	{
		TP_GAIN0[0]=tp0;
		TP_GAIN1[0]=tp1;
		TP_GAIN0[2]=tp0;
		TP_GAIN1[2]=tp1;
		TP_GAIN0[3]=tp0;
		TP_GAIN1[3]=tp1;
	}

}
