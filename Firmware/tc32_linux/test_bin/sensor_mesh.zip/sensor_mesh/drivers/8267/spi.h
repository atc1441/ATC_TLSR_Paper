#ifndef SPI_H
#define SPI_H

enum SPI_MODE{
	SPI_MODE0=0,
	SPI_MODE2,
	SPI_MODE1,
	SPI_MODE3,
};

enum SPI_PIN{
	SPI_PIN_GPIOA=0,
	SPI_PIN_GPIOB,
};


void spi_pin_init(enum SPI_PIN gpio_pin_x);

void spi_master_init(unsigned char div_clock,enum SPI_MODE mode);
void spi_slave_init(unsigned char div_clock,enum SPI_MODE mode);

void spi_write_buff(unsigned short addr ,unsigned char* pbuff,unsigned int len);
void spi_read_buff(unsigned short addr,unsigned char* pbuff,unsigned int len);



#endif

