/*
 * emitest.c
 *
 *  Created on: 2016-6-30
 *      Author: Administrator
 */
#include "rf.h"
#include "bsp.h"
unsigned char  emi_var[5];
unsigned char  emi_tx[16]  __attribute__ ((aligned (4))) = {0xc,0x00,0x00,0x00,0x00,0x20,0xaa,0xbb};
int state0,state1,state2,state3;
unsigned char depth=1;
#define STATE0		0x1234
#define STATE1		0x5678
#define STATE2		0xabcd
#define STATE3		0xef01


// used in this file :
extern enum   M_RF_MODE   g_rf_mode;

/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) test  initialization
*
*	@param		None
*
*
*	@return		None
*/

int Rf_EmiInit(void)
{
	// for registers recover.
	emi_var[0] = ReadAnalogReg(0xa5);
	emi_var[1] = read_reg8(0x8004e8);
	//emi_var[2] = read_reg8(0x800408);
	//emi_var[2] = read_reg8(0x800402);
	emi_var[3] = read_reg8(0x80050f);
	emi_var[4] = read_reg8(0x80050e);
	//emi_var[6] = read_reg8(0x800400);
	return 1;

}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) test  recovery setting
*
*	@param		None
*
*
*	@return		None
*/

int Rf_EmiCarrierRecovery(void)
{
	//reset zb & dma
	write_reg16(0x800060, 0x0480);
	write_reg16(0x800060, 0x0000);

	WriteAnalogReg (0xa5, emi_var[0]);
    write_reg8 (0x8004e8, emi_var[1]);
    if(( g_rf_mode == RF_MODE_BLE_2M ) )
	{
    	write_reg8 (0x800402, 0x2b);
	}
	else if(g_rf_mode == RF_MODE_BLE_1M )
	{
		write_reg8 (0x800402, 0x2b);
	}
	else if(g_rf_mode == RF_MODE_ZIGBEE_250K )
	{
		write_reg8 (0x800402, 0x26);
	}
//	write_reg8 (0x800402, emi_var[2]);
	write_reg8(0x80050f, emi_var[3]);
    write_reg8(0x80050e, emi_var[4]);
   // write_reg8(0x800400, emi_var[6]);
    return 1;

}

int pnGen(int state)
{
	int feed = 0;
	feed = (state&0x4000) >> 1;
	state ^= feed;
	state <<= 1;
	state = (state&0xfffe) + ((state&0x8000)>>15);
	return state;
}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) CarrierOnly Test
*
*	@param		power_level: set power level(0~14)
*				rf_chn	   : set tx channel((0 鈮�channel 鈮�100))
*
*
*	@return		None
*/
void Rf_EmiCarrierOnlyTest(enum M_RF_POWER power_level,signed char rf_chn)
{
	Rf_EmiCarrierRecovery();
	Rf_TrxStateSet(RF_MODE_TX,rf_chn);
	WaitUs(150);//wait pllclock

	Rf_PowerLevelSet(power_level);
	WriteAnalogReg(0xa5,0x44);   // for carrier  mode
	write_reg8 (0x8004e8, 0x04); // for  carrier mode
}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) CarrierData Test
*
*	@param		power_level: set power level(0~14)
*				rf_chn	   : set tx channel((0 鈮�channel 鈮�100))
*
*
*	@return		None
*/

void Rf_EmiCarrierDataTest(enum M_RF_POWER power_level,signed char rf_chn)
{

	int i;

	Rf_EmiCarrierRecovery();
	Rf_PowerLevelSet(power_level);
	Rf_TrxStateSet(RF_MODE_TX,rf_chn);
	WaitUs(150);//wait pllclock

	write_reg8(0x80050e,depth); // this size must small than the beacon_packet dma send length
	state0 = STATE0;
	state1 = STATE1;
	state2 = STATE2;
	state3 = STATE3;
	emi_tx[0] = depth*16-4;
//	if(( g_rf_mode == RF_MODE_NORDIC_2M ) )
//	{
//		emi_tx[0] = depth*16+1;
//	}
//	else if(g_rf_mode == RF_MODE_BLE_1M )
//	{
//		emi_tx[0] = depth*16+2;
//	}
//	else if(g_rf_mode == RF_MODE_ZIGBEE_250K )
//	{
//		emi_tx[0] = depth*16-1;
//	}
	write_reg32((emi_tx+depth*16-4),(state0<<16)+state1); // the last value
	write_reg8(0x80050f, 0x80);  // must fix to 0x80
	write_reg8(0x800402, 0x21);	//preamble length=1
    Rf_TxPkt(emi_tx);
}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) CarrierData Test Data Update
*
*	@param		None
*
*
*	@return		None
*/

void Rf_EmiDataUpdate(void)
{
	write_reg32((emi_tx+depth*16-4),(state0<<16)+state1); // the last value
	//advance PN generator
	state0 = pnGen(state0);
	state1 = pnGen(state1);
}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) Rx Test
*
*	@param		addr       :set receiving address pointer
*
*				buffer_size: set power level(0~14)
*				rf_chn	   : set tx channel((0 鈮�channel 鈮�100))
*
*
*	@return		None
*/

void Rf_EmiRxTest(unsigned char *addr,signed char rf_chn,signed char buffer_size,unsigned char  pingpong_en)
{


	Rf_RxBufferSet(addr,buffer_size,pingpong_en);
	Rf_TrxStateSet(RF_MODE_RX,rf_chn);
	WaitUs(200);//wait pllclock
	Rf_EmiCarrierRecovery();

	//Rf_BaseBandReset();
}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) Tx Test initialization
*
*	@param		power_level: set power level(0~14)
*				rf_chn	   : set tx channel((0 鈮�channel 鈮�100))
*
*
*	@return		None
*/

void Rf_EmiTxInit(enum M_RF_POWER power_level,signed char rf_chn)
{

	Rf_PowerLevelSet(power_level);
	Rf_TrxStateSet(RF_MODE_TX,rf_chn);
	WaitUs(200);//wait pllclock
	//Rf_BaseBandReset();
	Rf_EmiCarrierRecovery();

}
/********************************************************
*
*	@brief		Emi ( Electro Magnetic Interference ) CarrierData Test
*
*	@param		addr       :set tx address pointer
*
*
*	@return		None
*/

void Rf_EmiSingleTx(unsigned char *addr)
{
	Rf_TxPkt(addr);
	while(RF_TxFinish()==0);
	Rf_TxFinishClearFlag();
}
