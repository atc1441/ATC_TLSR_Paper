#include "bsp.h"
#include "gpio.h"
#include "spi.h"

void spi_pin_init(enum SPI_PIN gpio_pin_x){
	if(gpio_pin_x == SPI_PIN_GPIOB){
		write_reg8(0x80058e,read_reg8(0x80058e)&0x0f);///disable GPIO:B<4~7>
		write_reg8(0x8005b1,read_reg8(0x8005b1)|0xf0);///enable SPI function:B<4~7>

		write_reg8(0x8005b0,read_reg8(0x8005b0)&0xC3);///disable SPI function:A<2~5>
	}
	if(gpio_pin_x == SPI_PIN_GPIOA){
		write_reg8(0x800586,read_reg8(0x800586)&0xC3);///disable GPIO:A<2~5>
		write_reg8(0x8005b0,read_reg8(0x8005b0)|0x3C);///enable SPI function:A<2~5>

		write_reg8(0x8005b1,read_reg8(0x8005b1)&0x0f);///disable SPI function:B<4~7>
	}	
	write_reg8(0x80000a,read_reg8(0x80000a)|0x80);////enable spi 
}

void spi_master_init(unsigned char div_clock,enum SPI_MODE mode){
	write_reg8(0x80000a,read_reg8(0x80000a)|div_clock);/////spi clock=system clock/((div_clock+1)*2)
	write_reg8(0x800009,read_reg8(0x800009)|0x02);////enable master mode
	
	write_reg8(0x80000b,read_reg8(0x80000b)|mode);////select SPI mode,surpport four modes
}

void spi_slave_init(unsigned char div_clock,enum SPI_MODE mode){
	write_reg8(0x80000a,read_reg8(0x80000a)|div_clock);/////spi clock=system clock/((div_clock+1)*2)
	write_reg8(0x800009,read_reg8(0x800009)&0xfd);////disable master mode

	write_reg8(0x80000b,read_reg8(0x80000b)|mode);////select SPI mode,surpport four modes
}


void spi_write_buff(unsigned short addr ,unsigned char* pbuff,unsigned int len){
	unsigned int i = 0;
	write_reg8(0x800009,read_reg8(0x800009)&0xfe);////CS level is low
	write_reg8(0x800009,read_reg8(0x800009)&0xfb);///enable output
	write_reg8(0x800009,read_reg8(0x800009)&0xf7);///enable write
	
	/***send addr***/
	write_reg8(0x800008,(addr>>8)&0xff);/////high addr
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	write_reg8(0x800008,addr&0xff);/////low addr
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	
	/***send write command:0x00***/
	write_reg8(0x800008,0x00);/////0x80:read  0x00:write
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	/***send data***/
	for(i=0;i<len;i++){
		write_reg8(0x800008,pbuff[i]);
		while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	}
	/***pull up CS***/
	write_reg8(0x800009,read_reg8(0x800009)|0x01);///CS level is high
}


void spi_read_buff(unsigned short addr,unsigned char* pbuff,unsigned int len){
	unsigned int i = 0;
	unsigned char temp = 0;
	
	write_reg8(0x800009,read_reg8(0x800009)&0xfe);////CS level is low
	write_reg8(0x800009,read_reg8(0x800009)&0xfb);///enable output

	/***send addr***/
	write_reg8(0x800008,(addr>>8)&0xff);/////high addr
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	write_reg8(0x800008,addr&0xff);/////low addr
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	
	/***send read command:0x80***/
	write_reg8(0x800008,0x80);/////0x80:read  0x00:write
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status

	/***when the read_bit was set 1,you can read 0x800008 to take eight clock cycle***/
	write_reg8(0x800009,read_reg8(0x800009)|0x08);////set read_bit to 1
	temp = read_reg8(0x800008);///first byte isn't useful data,only take 8 clock cycle
	while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	
	/***send one byte data to read data***/
	for(i=0;i<len;i++){
		pbuff[i] = read_reg8(0x800008);///take 8 clock cycles
		while(read_reg8(0x800009)&0x40);/////bit<6>is busy status
	}
	/////pull up CS
	write_reg8(0x800009,read_reg8(0x800009)|0x01);///CS level is high
}




