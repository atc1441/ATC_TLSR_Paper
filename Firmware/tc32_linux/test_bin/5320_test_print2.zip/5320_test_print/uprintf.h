#ifndef  UPRINTF_H
#define  UPRINTF_H
extern void my_printf(const char *format, ...);
#endif