#include "bsp.h"
#include "uprintf.h"




void lwr_irq_hdlr() {

}




static inline  void delay(unsigned int ms)
{
	volatile unsigned int i,j;
	volatile unsigned char bc;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<20;j++)
		{
			bc++;
		}
	}
	
}
static void delay2(unsigned int ms)
{
	volatile unsigned int i,j;
	volatile unsigned char bc;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<20;j++)
		{
			bc++;
		}
	}
	
}
static inline void delay3(unsigned int ms)
{
	volatile unsigned int i,j;
	volatile unsigned char bc;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<20;j++)
		{
			bc++;
		}
	}
	
}



unsigned long  bug_cc;
unsigned long  d_cc;

unsigned char  array_test[4][16];

void sys_init( )
{
	bug_cc=4;
}

void fun1(int *a )
{
	fun2(a);
	*a+=1;
	fun3(a);
	*a+=1;

}

void fun2(int *b )
{
	*b=0;
	fun3(b);
}


void fun3(int *b )
{
	*b-=1;
}


void main()
{
	
	int aaa= -1;
    sys_init();
    fun1(&bug_cc);
	while(1) {
		if(bug_cc>10)  fun1(&bug_cc);
		bug_cc++;
		d_cc++;
		aaa++;


		write_reg8(0x8005ae, 0x10);
		write_reg8(0x8005ae,0x00);

	}
		
}
