#include "bsp.h"
//#include "config.h"
#define  DEBUG_MODE  1
#if(DEBUG_MODE==1)



void uart_putc (char c)
{
	//while (read_reg8(USBFIFO) & BIT1);
	write_reg8(EDPS_DAT, c);
}

void printb(unsigned char c) {
	unsigned char nib = c >> 4;
	if (nib > 9)	nib = nib + 87;
	else		nib = nib + 48;
	uart_putc (nib);

	nib = c & 15;
	if (nib > 9)	nib = nib + 87;
	else		nib = nib + 48;
	uart_putc (nib);
}

#define vaStart(list, param) list = (char*)((int)&param + sizeof(param))
#define vaArg(list, type) ((type *)(list += sizeof(type)))[-1]

void sysPutNumber(unsigned int w,int len) {
	int i;
	int c = w;
	int len_adj = (len>4) || (len<1) ? 4 : len;
	              
	for(i=len-1;i>=0;i--)
	{
		c = w >>(i*8);
		printb(c);
	}
}

static char *FormatItem(char *f, int a)
{		char c;
		int    fieldwidth = 0;
		int    flag = 0;
		
		while ((c = *f++) != 0)
		{
			if (c >= '0' && c <= '9')
			{
				fieldwidth = (fieldwidth * 10) + (c - '0');
			}
			else
			{
				switch (c)
				{
					case 'x': 
						flag = 16;
						break;
					default:
						uart_putc('*');
						flag = -1;
						break;
				}
			}
			if(flag!=0)
				break;
		}
		sysPutNumber(a,fieldwidth);
		return f;
		
}

void my_printf(const char *format, ...) {
	//va_list args;
	char *  args;
	char *  pcStr = format;
	vaStart( args, format);
	
	while (*pcStr)
	{                       /* this works because args are all ints */
	    	if (*pcStr == '%')
	        	pcStr = FormatItem(pcStr + 1, vaArg(args, int));
	    	else
	        	uart_putc(*pcStr++);
	}
	
}



#endif
